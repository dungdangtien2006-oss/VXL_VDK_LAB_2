/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"

/* ĐỊNH NGHĨA CÁC CHÂN TEST ĐỂ KHÔNG BỊ LỖI UNDECLARED */
#ifndef Led_Test_All_Pin
#define Led_Test_All_Pin GPIO_PIN_0
#define Led_Test_All_GPIO_Port GPIOA
#endif

#ifndef Led_Test_Timer_Pin
#define Led_Test_Timer_Pin GPIO_PIN_1
#define Led_Test_Timer_GPIO_Port GPIOA
#endif

#ifndef Led_5_Pin
#define Led_5_Pin GPIO_PIN_5
#define Led_5_GPIO_Port GPIOA
#endif

TIM_HandleTypeDef htim2;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);

/* ========================================= */
/* KHAI BÁO 2 SOFTWARE TIMERS (Bài 8)        */
/* ========================================= */
int timer0_counter = 0; // Timer 0 dùng cho đồng hồ và DOT
int timer0_flag = 0;

int timer1_counter = 0; // Timer 1 dùng cho quét LED
int timer1_flag = 0;

int TIMER_CYCLE = 10; // Ngắt timer chạy mỗi 10ms

void setTimer0(int duration){
    timer0_counter = duration / TIMER_CYCLE;
    timer0_flag = 0;
}

void setTimer1(int duration){
    timer1_counter = duration / TIMER_CYCLE;
    timer1_flag = 0;
}

void timer_run(){
    if(timer0_counter > 0){
        timer0_counter--;
        if(timer0_counter == 0) timer0_flag = 1;
    }
    if(timer1_counter > 0){
        timer1_counter--;
        if(timer1_counter == 0) timer1_flag = 1;
    }
}
/* ========================================= */

void clear7SEG() {
    HAL_GPIO_WritePin(Led7_a_GPIO_Port, Led7_a_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(Led7_f_GPIO_Port, Led7_f_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(Led7_e_GPIO_Port, Led7_e_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(Led7_d_GPIO_Port, Led7_d_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(Led7_g_GPIO_Port, Led7_g_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(Led7_b_GPIO_Port, Led7_b_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(Led7_c_GPIO_Port, Led7_c_Pin, GPIO_PIN_SET);
}

static const uint8_t seg_off_mask[10] = {
    0x40, // 0
    0x79, // 1
    0x24, // 2
    0x30, // 3
    0x19, // 4
    0x12, // 5
    0x02, // 6
    0x78, // 7
    0x00, // 8
    0x10  // 9
};

void display7SEG(int num) {
    uint16_t off_mask;
    if (num >= 0 && num <= 9) off_mask = seg_off_mask[num];
    else off_mask = 0x7F;
    uint16_t on_mask = (~off_mask) & 0x7F;

    HAL_GPIO_WritePin(GPIOB, off_mask, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOB, on_mask, GPIO_PIN_RESET);
}
const unsigned int MAX_LED = 4;
int led_buffer[4] = {1, 2, 3, 4};
unsigned int index_led = 0;

void update7SEG(int index) {
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9, GPIO_PIN_SET);

    switch (index) {
        case 0:
            display7SEG(led_buffer[0]);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_RESET); // EN0
            break;
        case 1:
            display7SEG(led_buffer[1]);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET); // EN1
            break;
        case 2:
            display7SEG(led_buffer[2]);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET); // EN2
            break;
        case 3:
            display7SEG(led_buffer[3]);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_RESET); // EN3
            break;
        default:
            break;
    }
}

void updateClockBuffer(int hour, int minute) {
	led_buffer[0] = hour / 10;
	led_buffer[1] = hour % 10;
	led_buffer[2] = minute / 10;
	led_buffer[3] = minute % 10;
}

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_TIM2_Init();

  HAL_TIM_Base_Start_IT(&htim2);

  int hour = 15, minute = 8, second = 50;
  updateClockBuffer(hour, minute);

  setTimer0(1000);
  setTimer1(250);

  while (1)
  {
	  if (timer0_flag == 1) {
		  second++;
		  if (second >= 60) {
			  second = 0;
			  minute++;
		  }
		  if (minute >= 60) {
			  minute = 0;
			  hour++;
		  }
		  if (hour >= 24) {
			  hour = 0;
		  }
		  updateClockBuffer(hour, minute);

		  HAL_GPIO_TogglePin(DOT_GPIO_Port, DOT_Pin);

		  setTimer0(1000);
	  }

      if (timer1_flag == 1) {
          update7SEG(index_led++);
          if (index_led >= MAX_LED) {
              index_led = 0;
          }

          setTimer1(250);
      }
  }
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_TIM2_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 9;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  HAL_GPIO_WritePin(GPIOA, Led_Test_All_Pin|Led_Test_Timer_Pin|DOT_Pin|Led_5_Pin
                          |EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin, GPIO_PIN_RESET);

  HAL_GPIO_WritePin(GPIOB, Led7_a_Pin|Led7_b_Pin|Led7_c_Pin|Led7_d_Pin
                          |Led7_e_Pin|Led7_f_Pin|Led7_g_Pin, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = Led_Test_All_Pin|Led_Test_Timer_Pin|DOT_Pin|Led_5_Pin
                          |EN0_Pin|EN1_Pin|EN2_Pin|EN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = Led7_a_Pin|Led7_b_Pin|Led7_c_Pin|Led7_d_Pin
                          |Led7_e_Pin|Led7_f_Pin|Led7_g_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

void HAL_TIM_PeriodElapsedCallback ( TIM_HandleTypeDef * htim )
{
    if (htim->Instance == TIM2) {
        timer_run();
    }
}

void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif
